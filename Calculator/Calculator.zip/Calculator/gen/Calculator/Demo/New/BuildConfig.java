/** Automatically generated file. DO NOT MODIFY */
package Calculator.Demo.New;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}